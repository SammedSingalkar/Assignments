const { check,  validationResult } = require('express-validator');
const express = require('express')
const app = express()
app.use(express.json())

// RENDER LOGIN PAGE
module.exports.loginPage = (req, res) => {
    res.render('accounts/login', {title: "Login"})
}

// PROCESS LOGIN REQUEST
module.exports.login = (req, res) => {

    check('email').isEmpty().withMessage('defefe')

    const errors = validationResult(req)

    // const user = {
    //     username: req.body.username,
    //     email: req.body.email,
    //     password: req.body.password
    // }
    console.log(errors)
    res.render('accounts/errors', {title: "Errors", errors: errors})
}
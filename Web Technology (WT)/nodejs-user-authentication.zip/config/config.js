// DEFINE CONSTANTS
const mongoose = require("mongoose");

// CONNECT TO DATABASE SERVER
mongoose
  .connect(process.env.DB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    console.log("connected");
  })
  .catch((err) => {
    console.log(err);
  });

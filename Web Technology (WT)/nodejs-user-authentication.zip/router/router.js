const router = require('express').Router()

// CONTROLLERS
const accountsController = require('../controllers/accountsController')

// ROUTER MIDDLEWARE
router.use((req, res, next) => { next() })

// RENDER HOME PAGE
router.get('/', accountsController.loginPage)

// PROCESS LOGIN REQUEST
router.post('/login', accountsController.login)

// 404 Page
// router.use(homeController._404)

// EXPORT ROUTER FUNCTION
module.exports = router
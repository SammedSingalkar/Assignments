// DEFINE CONSTATNTS
const express = require("express");
const app = express();
const PORT = 8080 || process.env.PORT;
const path = require("path");
const bodyParser = require("body-parser");
require("dotenv").config();
require("./config/config");
require("./middleware/middleware");

// REQUIRE FILES
const router = require("./router/router");

// MIDDLEWARES
app.use("/public", express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use((req, res, next) => {
  res.locals.path = req.path;
  next();
});

// SET A VIEW ENGINE
app.set("view engine", "pug");

// ERROR HANDLING
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Access-Control-Allow-Origin,Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers,Authorization"
  );
  next();
});

// ROUTER
app.use(router);

// LISTEN TO SERVER REQUEST
app.listen(PORT, () => {
  console.log("Server Is Running On Port", PORT);
});
